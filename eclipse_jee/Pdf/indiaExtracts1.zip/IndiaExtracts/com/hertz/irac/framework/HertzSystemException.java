package com.hertz.irac.framework;

public class HertzSystemException extends Exception {
	public HertzSystemException(String message) {
		super (message);
	}
}
