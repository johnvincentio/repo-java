/********************************************************************
*			Copyright (c) 2006 The Hertz Corporation				*
*			  All Rights Reserved.  (Unpublished.)					*
*																	*
*		The information contained herein is confidential and		*
*		proprietary to The Hertz Corporation and may not be			*
*		duplicated, disclosed to third parties, or used for any		*
*		purpose not expressly authorized by it.  Any unauthorized	*
*		use, duplication, or disclosure is prohibited by law.		*
*																	*
*********************************************************************/

package com.hertz.herc.presentation.util.framework;

import java.util.Iterator;

import com.hertz.herc.rentalman.business.session.RentalManServicesBean;
import com.hertz.hercutil.company.RMAccountType;
import com.hertz.hercutil.company.RMNarpAccountInfo;
import com.hertz.hercutil.rentalman.reports.data.EquipmentHistoryInfo;
import com.hertz.irac.framework.HertzSystemException;

/**
 * Encapsulate tasks related to RentalMan data extracts.
 * 
 * @author John Vincent
 */

public class RentalManDataExtractHelper {
	public static EquipmentHistoryInfo doReportEquipmentHistory (RMAccountType rmAccountType, 
			String selectedYear, boolean[] csvColumns) throws HertzSystemException {
		System.out.println(">>> ReportsExtractHandler::doReportEquipmentHistory");

		EquipmentHistoryInfo equipmentHistoryInfo = new EquipmentHistoryInfo();

		String jobNumber = "";
		String orderBy = "";

		System.out.println(rmAccountType.toString());
		if (rmAccountType.isNarp()) {
			RMNarpAccountInfo rmNarpAccountInfo = (RMNarpAccountInfo) rmAccountType;
			Iterator iterator1 = rmNarpAccountInfo.getItems();
			while (iterator1.hasNext()) {
				RMAccountType rmLocalAccount = (RMAccountType) iterator1.next();
				if (rmLocalAccount == null) continue;

				//TODO; check if this member has access to this account
				equipmentHistoryInfo.add (RentalManServicesBean.getEquipmentHistoryInfo (rmLocalAccount,
						jobNumber, selectedYear, orderBy, 0));
			}
		}
		else {
			equipmentHistoryInfo.add (RentalManServicesBean.getEquipmentHistoryInfo (rmAccountType,
					jobNumber, selectedYear, orderBy, 0));
		}
		System.out.println(equipmentHistoryInfo.getCSV(true, csvColumns));

		System.out.println("<<< ReportsExtractHandler::doReportEquipmentHistory");
		return equipmentHistoryInfo;
	}
}
