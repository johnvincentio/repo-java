package com.hertz.herc.rentalman.reports;

import com.hertz.herc.presentation.util.framework.RentalManDataExtractHelper;
import com.hertz.hercutil.company.RMAccountInfo;
import com.hertz.hercutil.company.RMAccountType;
import com.hertz.hercutil.company.RMAccountsInfo;
import com.hertz.hercutil.company.RMNarpAccountInfo;
import com.hertz.hercutil.rentalman.reports.data.EquipmentHistoryInfo;

public class EquipmentHistoryTest {
	public static void main (String[] args) {
		try {
			long start = System.currentTimeMillis();
			(new EquipmentHistoryTest()).doTest1();
			System.out.println("test total time : " + (System.currentTimeMillis() - start));
		}
		catch (Exception ex) {
			System.out.println("Exception; "+ex.getMessage());
		}
	}
	private void doTest1() throws Exception {
		System.out.println(">>> D1:doTest1 - 1");
		RMAccountType rmAccountType;
//		rmAccountType = HercRMHelper.getAccount (accountNumber, countryCode);	//TODO; get real data later
		rmAccountType = makeNarpData ();
//		rmAccountType = makeData ();
		
		String selectedYear = "2008";	// 2007
		boolean[] csvColumns = {true, true, true, true, true, true, true, true, true, true, true, true};
//		boolean[] csvColumns = {true, true, true, true, true, false, false, true, true, true, true, false};

		EquipmentHistoryInfo equipmentHistoryInfo = RentalManDataExtractHelper.doReportEquipmentHistory (rmAccountType,
						selectedYear, csvColumns);
		StringBuffer buf = equipmentHistoryInfo.getCSV (true, csvColumns);

		System.out.println(buf);
	}

	private static RMAccountType makeNarpData () {
		RMAccountInfo rmAccountInfo = Utils.makeRMAccountInfo ("4312", 1, "JV Inc", "12 abc ave", "", "Flint", "MI", "03423");
		RMAccountInfo corpLinkRMAccountInfo = Utils.makeRMAccountInfo ("9999", 1, "Corp Inc", "12 abc ave", "", "Flint", "MI", "03423");
		RMAccountsInfo rmAccountsInfo = new RMAccountsInfo();
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("140276", 1, "JV Inc", "12 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1051245", 1, "JV Inc", "45 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1057733", 1, "JV Inc", "200 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1062364", 1, "JV Inc", "21 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1069213", 1, "JV Inc", "4566 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1071383", 1, "JV Inc", "65 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1739382", 1, "JV Inc", "643 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("1744444", 1, "JV Inc", "77 abc ave", "", "Flint", "MI", "03423"));
		rmAccountsInfo.add (Utils.makeRMAccountInfo ("2619540", 1, "JV Inc", "42376 abc ave", "", "Flint", "MI", "03423"));
		RMNarpAccountInfo rmNarpAccountInfo = new RMNarpAccountInfo (rmAccountInfo, 
				corpLinkRMAccountInfo, rmAccountsInfo);
		return rmNarpAccountInfo;
	}

	private static RMAccountType makeData () {
		RMAccountInfo rmAccountInfo = Utils.makeRMAccountInfo ("2821732", 1, "Ob Inc", "12 def ave", "", "Washington", "DC", "00000");
		return rmAccountInfo;
	}
}
