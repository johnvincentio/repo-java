/********************************************************************
*			Copyright (c) 2006 The Hertz Corporation				*
*			  All Rights Reserved.  (Unpublished.)					*
*																	*
*		The information contained herein is confidential and		*
*		proprietary to The Hertz Corporation and may not be			*
*		duplicated, disclosed to third parties, or used for any		*
*		purpose not expressly authorized by it.  Any unauthorized	*
*		use, duplication, or disclosure is prohibited by law.		*
*																	*
*********************************************************************/

package com.hertz.herc.rentalman.business.session;

import java.sql.Connection;

import com.hertz.herc.rentalman.business.dao.DBRentalManConstants;
import com.hertz.herc.rentalman.reports.dao.EquipmentHistoryDAO;
import com.hertz.hercutil.company.RMAccountType;
import com.hertz.hercutil.presentation.DAOUtils;
import com.hertz.hercutil.rentalman.reports.data.EquipmentHistoryInfo;
import com.hertz.irac.framework.HertzSystemException;

/**
 * 
 * @author John Vincent
 */

public class RentalManServicesBean {

	/**
	 * handles the connection, makes the call to get the data, and disconnects.
	 * 
	 * @param rmAccountType
	 * @param jobnumber
	 * @param selectedYear
	 * @param str_orderBy
	 * @param start_num
	 * @return
	 * @throws HertzSystemException
	 */
	public static EquipmentHistoryInfo getEquipmentHistoryInfo (RMAccountType rmAccountType,  
			String jobnumber, String selectedYear, 
			String str_orderBy, int start_num) throws HertzSystemException {

		System.out.println(">>> RentalManServicesBean::getEquipmentHistoryInfo");
		Connection connection = null;
		try {
			//TODO; may need to handle get connection by some other means. Suggest you use DAOUtils.getDSConnection

			connection = DAOUtils.getDSConnection (DBRentalManConstants.getDatasourceName(rmAccountType.getCountryCode()));
			EquipmentHistoryInfo equipmentHistoryInfo = 
				(new EquipmentHistoryDAO()).performExtract (connection, 
						DBRentalManConstants.getRentalManCode(rmAccountType.getCountryCode()), 
						rmAccountType, jobnumber, selectedYear, str_orderBy, start_num);
			System.out.println("<<< RentalManServicesBean::getEquipmentHistoryInfo");
			return equipmentHistoryInfo;
		}
		catch (Exception ex) {
			throw new HertzSystemException("Exception in getEquipmentHistoryInfo) " + ex);
		}
		finally {
			try {
				if (connection != null) DAOUtils.closeConnection(connection);
			}
			catch (Exception cex) {}
		}
	}
}

