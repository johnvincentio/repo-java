/********************************************************************
*			Copyright (c) 2006 The Hertz Corporation				*
*			  All Rights Reserved.  (Unpublished.)					*
*																	*
*		The information contained herein is confidential and		*
*		proprietary to The Hertz Corporation and may not be			*
*		duplicated, disclosed to third parties, or used for any		*
*		purpose not expressly authorized by it.  Any unauthorized	*
*		use, duplication, or disclosure is prohibited by law.		*
*																	*
*********************************************************************/

package com.hertz.hercutil.rentalman.reports.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.io.Serializable;

/**
 * Class to encapsulate the Equipment History Collection
 * 
 * @author John Vincent
 */

public class EquipmentHistoryInfo implements Serializable {
	private ArrayList m_list = new ArrayList();

	private Iterator getItems() {return m_list.iterator();}
	public void add (EquipmentHistoryItemInfo item) {m_list.add(item);}
	public void add (EquipmentHistoryInfo equipmentHistoryInfo) {
		for (Iterator iter = equipmentHistoryInfo.getItems(); iter.hasNext(); )
			m_list.add((EquipmentHistoryItemInfo) iter.next());
	}

	public StringBuffer getCSV (boolean bHeader, boolean[] csvColumns) {
		StringBuffer buf = new StringBuffer();
		if (bHeader) buf.append (getCsvHeader(csvColumns)).append("\n");
		boolean bFirst = true;
		for (Iterator iter = getItems(); iter.hasNext(); ) {
			EquipmentHistoryItemInfo item = (EquipmentHistoryItemInfo) iter.next();
			if (! bFirst) buf.append("\n");
			bFirst = false;
			buf.append (item.getCsvData (csvColumns));
		}
		return buf;
	}

	private String getCsvHeader (boolean[] csvColumns) {
		StringBuffer buf = new StringBuffer();
		if (csvColumns[0]) buf.append ("Account#, ");
		if (csvColumns[1]) buf.append ("Account Name, ");
		if (csvColumns[2]) buf.append ("Address, ");
		if (csvColumns[3]) buf.append ("City, ");
		if (csvColumns[4]) buf.append ("State, ");
		if (csvColumns[5]) buf.append ("Country, ");
		if (csvColumns[6]) buf.append ("Cat-Class, ");
		if (csvColumns[7]) buf.append ("Description, ");
		if (csvColumns[8]) buf.append ("Rental Days, ");
		if (csvColumns[9]) buf.append ("# of Trans, ");
		if (csvColumns[10]) buf.append ("Rental Amount, ");
		if (csvColumns[11]) buf.append ("Rental Year, ");
		return buf.toString(); 
	}
	
	public String toString() {
		StringBuffer buf = new StringBuffer();
		for (int i=0; i<m_list.size(); i++)
			buf.append(((EquipmentHistoryItemInfo) m_list.get(i)).toString());
		return "("+buf.toString()+")";
	}
}
