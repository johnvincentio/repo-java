/********************************************************************
*			Copyright (c) 2006 The Hertz Corporation				*
*			  All Rights Reserved.  (Unpublished.)					*
*																	*
*		The information contained herein is confidential and		*
*		proprietary to The Hertz Corporation and may not be			*
*		duplicated, disclosed to third parties, or used for any		*
*		purpose not expressly authorized by it.  Any unauthorized	*
*		use, duplication, or disclosure is prohibited by law.		*
*																	*
*********************************************************************/

package com.hertz.hercutil.rentalman.reports.data;

import java.io.Serializable;

import com.hertz.hercutil.company.RMAccountType;

/**
 * Class to encapsulate one Equipment History record 
 * 
 * @author John Vincent
 */

public class EquipmentHistoryItemInfo implements Serializable {
	private RMAccountType rmAccountType;
	private String category;
	private String classification;
	private String description;
	private String rentalDays;
	private String transactions;
	private String rentalAmount;
	private String rentalYear;
	public EquipmentHistoryItemInfo (RMAccountType rmAccountType, 
			String category, String classification, String description,
			String rentalDays, String transactions, String rentalAmount,
			String rentalYear) {
		this.rmAccountType = rmAccountType;
		this.category = category.trim();
		while (this.category.length() < 3) {
			this.category = "0" + this.category;
		}
		this.classification = classification.trim();
		while (this.classification.length() < 4) {
			this.classification = "0" + this.classification;
		}
		this.description = description.trim().replace('"', ' ');
		this.rentalDays = rentalDays.trim();
		this.transactions = transactions.trim();
		this.rentalAmount = rentalAmount.trim();
		this.rentalYear = rentalYear.trim();
	}

	public StringBuffer getCsvData (boolean[] csvColumns) {
		StringBuffer buf = new StringBuffer();
		if (csvColumns[0]) buf.append ("\"").append (rmAccountType.getAccountNumber()).append("\",");
		if (csvColumns[1]) buf.append ("\"").append (rmAccountType.getBusiness()).append("\",");
		if (csvColumns[2]) buf.append ("\"").append (rmAccountType.getAddress1()).append("\",");
		if (csvColumns[3]) buf.append ("\"").append (rmAccountType.getCity()).append("\",");
		if (csvColumns[4]) buf.append ("\"").append (rmAccountType.getState()).append("\",");
		if (csvColumns[5]) buf.append ("\"").append (rmAccountType.getCountry()).append("\",");
		if (csvColumns[6]) buf.append ("\"").append (category).append("-").append(classification).append("\",");
		if (csvColumns[7]) buf.append ("\"").append (description).append("\",");
		if (csvColumns[8]) buf.append ("\"").append (rentalDays).append("\",");
		if (csvColumns[9]) buf.append ("\"").append (transactions).append("\",");
		if (csvColumns[10]) buf.append ("\"").append (rentalAmount).append("\",");
		if (csvColumns[11]) buf.append ("\"").append (rentalYear).append("\"");
		return buf;
	}
}
