This directory contains the dictionary file.
It is a text file containing over 70,000 words placed in alphabetical order.