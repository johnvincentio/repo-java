This directory contains the class files of the 'Scrabble in Java' game.

----------------------------------------------------------------------------------------
Copyright (c) 1997 by Lior Shadhan & Koby Fructhnis. 
All Rights on the 'Scrabble in Java' game are Reserved to Lior Shadhan & Koby Fructhnis.

The game is a FreeWare, under the condition that
none of its files will be changed or replaced in any way !!!
----------------------------------------------------------------------------------------

Use Scrabble.bat in order to start the application !

Please note:
------------
First you have to edit the Scrabble.bat file,
according to the instruction in it.