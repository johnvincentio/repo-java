This directory contains the help files of the 'Scrabble in Java'
game. The help files are written in HTML format.

----------------------------------------------------------------------------------------
Copyright (c) 1997 by Lior Shadhan & Koby Fructhnis. 
All Rights on the 'Scrabble in Java' game are Reserved to Lior Shadhan & Koby Fructhnis.

The game is a FreeWare, under the condition that
none of its files will be changed or replaced in any way !!!
----------------------------------------------------------------------------------------