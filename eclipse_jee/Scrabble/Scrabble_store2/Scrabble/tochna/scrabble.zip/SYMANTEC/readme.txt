This directory contains 3rd party classes, needed by the game.
