This directory contains images that are being used by
the 'Scrabble in Java' game.

----------------------------------------------------------------------------------------
Copyright (c) 1997 by Lior Shadhan & Koby Fructhnis. 
All Rights on the 'Scrabble in Java' game are Reserved to Lior Shadhan & Koby Fructhnis.

The game is a FreeWare, under the condition that
none of its files will be changed or replaced in any way !!!
----------------------------------------------------------------------------------------